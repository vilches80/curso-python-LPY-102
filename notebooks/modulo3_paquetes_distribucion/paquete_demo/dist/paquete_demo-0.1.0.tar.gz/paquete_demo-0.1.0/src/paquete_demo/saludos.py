#import pandas as pd

def hola(): return 'Hola desde paquete_demo'

#def manejadatos():
    #df = pd.DataFrame([])
